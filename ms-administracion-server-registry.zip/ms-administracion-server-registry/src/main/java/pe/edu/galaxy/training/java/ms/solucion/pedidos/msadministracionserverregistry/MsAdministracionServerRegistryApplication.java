package pe.edu.galaxy.training.java.ms.solucion.pedidos.msadministracionserverregistry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsAdministracionServerRegistryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsAdministracionServerRegistryApplication.class, args);
	}

}
