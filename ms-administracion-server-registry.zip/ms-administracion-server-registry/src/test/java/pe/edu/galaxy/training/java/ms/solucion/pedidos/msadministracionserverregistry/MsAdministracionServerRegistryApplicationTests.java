package pe.edu.galaxy.training.java.ms.solucion.pedidos.msadministracionserverregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsAdministracionServerRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
