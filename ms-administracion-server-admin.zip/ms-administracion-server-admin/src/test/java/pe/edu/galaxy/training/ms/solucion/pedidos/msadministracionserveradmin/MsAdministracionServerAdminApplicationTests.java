package pe.edu.galaxy.training.ms.solucion.pedidos.msadministracionserveradmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsAdministracionServerAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
