package pe.edu.galaxy.training.java.ms.solucion.pedidos.msadministracionserverconfig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsAdministracionServerConfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsAdministracionServerConfigApplication.class, args);
	}

}
