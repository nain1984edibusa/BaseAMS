package pe.edu.galaxy.training.java.ms.solucion.pedidos.msadministracionserverconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsAdministracionServerConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
